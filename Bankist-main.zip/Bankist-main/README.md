# Bankist
The given app is a simulation of a bank.
1. Jonas Schmedtann is from Portugal with username: JS and pin: 1111.
2. Apurv Anand is from India with username: AA and pin: 2222.
3. Steven Thomas Williams is from USA with username: STW and pin: 3333.
4. Shinosuke Ohara is from Japan with username: SO and pin: 4444.

Please use the above usernames and pins for login.
One can take loan, transfer money and close his/ her account in this app.

Assumption: The only assumption used in this app is that on currency transfer from 1 person to another, even though currency changes but the change is 1:1 i.e 100Rs transfer
is equivalent to 100 USD transfer == 100 Yen transfer == 100 Euros Transfer.   
